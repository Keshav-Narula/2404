#include <iostream>

using namespace std;

int main(){
	cout << "Hello COMP2404A and B!"<<endl;
}

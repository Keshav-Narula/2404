#include <iostream>

using namespace std;

void foo2(){
    cout<< "from COMP2404 in foo2!"<<endl;
}
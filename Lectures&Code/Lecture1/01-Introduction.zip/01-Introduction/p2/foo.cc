#include<iostream>
//#include "p2.cc"

using namespace std;

//forward declaration
void foo2();
void foo();

int main(){
    cout<<"Hello world";
    foo2();
}

void foo(){
    cout<<" from comp2404!"<<endl;
}
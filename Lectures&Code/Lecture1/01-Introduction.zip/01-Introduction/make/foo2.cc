#include <iostream>

using namespace std;

void foo2(){
    cout<< " from COMP2404A in foo2!"<<endl;
}
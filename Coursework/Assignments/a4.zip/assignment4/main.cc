#include <iostream>
#include "AlbumCreator.h"

using namespace std;

int main(){
    AlbumCreator ab;
    ab.launch();
    return 0;
}
#ifndef TESTVIEW_H
#define TESTVIEW_H

#include <iostream>
#include <string>

using namespace std;

class TestView {
		
	public:
    	void showMenu(int&);	
};
#endif
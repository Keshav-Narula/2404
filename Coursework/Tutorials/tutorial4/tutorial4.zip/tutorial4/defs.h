#ifndef DEFS_H
#define DEFS_H

#define ARR_SIZE 3

#endif